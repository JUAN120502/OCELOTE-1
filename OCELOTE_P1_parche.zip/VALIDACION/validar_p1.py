"""OCELOTE P1: Lua 5.1 with explicit DCS mocks. Does not run DCS or the EFM.
Usage: python validar_p1.py MOD_ROOT [--source-zip supplied_A-29.zip]
Dependency: Python 3 + lupa==2.6 (module lupa.lua51).
Reads inputs only; never writes originals, backups, or compiled Lua files.
"""
import argparse
import math
from pathlib import Path
import zipfile
from lupa.lua51 import LuaRuntime

parser = argparse.ArgumentParser()
parser.add_argument('root', type=Path)
parser.add_argument('--source-zip', type=Path)
args = parser.parse_args()
root = args.root.resolve()
EICAS = 'Cockpit/Scripts/Systems/CMFD/eicas.lua'
INDICATOR = 'Cockpit/Scripts/CMFD/Indicator/CMFD_EICAS.lua'
CONFIG = 'Cockpit/Scripts/Systems/CMFD/ocelote_p1.lua'
MODIFIED = {'loadout.lua', 'A-29B.lua', 'FM/config.lua', EICAS, INDICATOR, 'entry.lua'}
checks = 0

def check(condition, message):
    global checks
    assert condition, message
    checks += 1

def read(name):
    return (root/name).read_text(encoding='utf-8')

def lua():
    return LuaRuntime(unpack_returned_tuples=True)

def plain(value):
    if hasattr(value, 'items'):
        return {k: plain(v) for k, v in value.items()}
    return value

def db(source):
    vm = lua()
    vm.execute('''
        current_mod_path = "MOD"
        function _(s) return s end
        function noop() end
        mount_vfs_model_path=noop; mount_vfs_texture_path=noop
        mount_vfs_liveries_path=noop; mount_vfs_sound_path=noop
        function aircraft_task(t) return t end
        function MG_20(t) return t end
        function pylon(...) return {...} end
        function add_aircraft(t) aircraft=t end
        loads={}
        function declare_loadout(t) loads[t.CLSID]=t end
        -- Constants are symbolic names in this mock, not DCS enum values.
        setmetatable(_G, {__index=function(_, k) return k end})
    ''')
    vm.execute(source)
    return vm

vm = lua()
check(vm.eval('_VERSION') == 'Lua 5.1', 'real Lua 5.1 required')
for name in sorted(MODIFIED | {CONFIG}):
    # loadstring compiles without executing DCS APIs.
    fn = vm.eval('function(s,n) local f,e=loadstring(s,n); assert(f,e); return true end')
    check(fn(read(name), '@'+name), name)
print('PASS: 7 production Lua files compile under Lua 5.1')

loads = plain(db(read('loadout.lua')).globals().loads)
under = '{OCELOTE_P1_TANK_UNDERWING}'
ventral = '{OCELOTE_P1_TANK_VENTRAL}'
legacy = '{A-29B TANK}'
for clsid, usable, full in [(under, 243, 297.6), (ventral, 224, 278.6)]:
    t = loads[clsid]
    check(math.isclose(t['Weight_Empty'], 54.6), 'dry mass')
    check(math.isclose(t['Weight'], full), 'full mass')
    check(math.isclose(t['Weight']-t['Weight_Empty'], usable), 'usable fuel')
    check(math.isclose(t['Weight_Empty']-48.6, 6), 'unusable is dry mass')
    check(t['Cx_pil'] == loads[legacy]['Cx_pil'] == 0.002, 'drag preserved')
    check(t['Elements'][1]['ShapeName'] == loads[legacy]['Elements'][1]['ShapeName'], 'shared model')
air = plain(db(read('A-29B.lua')).globals().aircraft)
for i, p in air['Pylons'].items():
    n = p[1]
    clsids = {item['CLSID'] for item in p[7].values()}
    check((under in clsids) == (n in [2,4]), 'underwing stations')
    check((ventral in clsids) == (n == 3), 'ventral station')
    check((legacy in clsids) == (n in [2,3,4]), 'legacy stations')
check(air['M_empty'] == 3356 and air['M_fuel_max'] == 495, 'baseline masses')
check(math.isclose(480/air['M_fuel_max']*100, 96.9696969697), 'pressure refueling percentage')
check(math.isclose(2*loads[under]['Weight']+loads[ventral]['Weight'], 873.8), 'three full tanks')
check(2*243+224 == 710, 'external usable total')
fm = lua(); fm.execute(read('FM/config.lua'))
gear = plain(fm.globals().suspension)
check(len(gear) == 3, 'three suspension entries')
for i in [2,3]:
    check(gear[i]['wheel_radius'] == 0.563, 'main gear radius')
    check(gear[i]['amortizer_direct_damper_force_factor'] == 52500, 'direct damping')
print('PASS: tank balances, permitted stations, legacy ID and symmetric suspension (mock registration)')

config_vm=lua(); config=config_vm.execute(read(CONFIG))
check(config.tq_reference_percent is False, 'reference hidden by default')
valid = [20, 20.01, 50, 70, 87, 100, 119.99, 120]
invalid = [None, False, True, '87', '', {}, float('nan'), float('inf'), -float('inf'), -1, 0, 19.999, 120.001, 225]
for val in valid:
    angle, visible = config.torque_marker(val)
    check(visible == 1 and math.isclose(angle, -(val-70)*math.pi/60, abs_tol=1e-12), 'valid reference')
for val in invalid:
    if isinstance(val, dict): val = config_vm.table()
    check(config.torque_marker(val) == (0,0), 'invalid reference hidden')

# Execute the real full update_eicas(), including real engine_api.lua, in mocks.
def eicas_vm(source, reference=False):
    v=lua()
    v.execute('''
        params={}; warnings={}; cautions={}; voices={}
        function get_param_handle(n)
            if not params[n] then
                params[n]={value=0, get=function(self) return self.value end,
                    set=function(self,x) self.value=x end}
            end
            return params[n]
        end
        rpm=0.9; wow=1; total_fuel=495; fuel_consumption=0.05
        sensor_data={
            getEngineLeftRPM=function() return rpm end,
            getWOW_LeftMainLandingGear=function() return wow end,
            getBarometricAltitude=function() return 609.6 end,
            getThrottleLeftPosition=function() return 0.8 end,
            getEngineLeftTemperatureBeforeTurbine=function() return 600 end,
            getEngineLeftFuelConsumption=function() return fuel_consumption end,
            getTotalFuelWeight=function() return total_fuel end,
            getFlapsPos=function() return 0 end,
            getSpeedBrakePos=function() return 0 end,
            getSelfCoordinates=function() return 0,609.6,0 end,
        }
        function get_base_data() return sensor_data end
        function get_elec_main_bar_ok() return true end
        function get_avionics_onground() return wow>0 end
        function get_generator_on() return true end
        function get_aircraft_draw_argument_value(_) return 0 end
        function round_to(x, step) return math.floor(x/step+0.5)*step end
        function set_warning(id,x) warnings[id]=x end
        function set_caution(id,x) cautions[id]=x end
        function set_voice(id,x) voices[id]=x end
        function ids() return setmetatable({}, {__index=function(_,k) return k end}) end
        WARNING_ID=ids(); CAUTION_ID=ids(); VOICE_ID=ids()
        nav_fyt_list={{lat_m=18520,lon_m=0}}
        update_time_step=0.02
        LockOn_Options={script_path="SCRIPT/",init_conditions={birth_place="GROUND_HOT"}}
    ''')
    loaded=[]
    cfg=v.execute(read(CONFIG)); cfg.tq_reference_percent=reference
    def dofile(path):
        loaded.append(path)
        if path == 'SCRIPT/Systems/CMFD/ocelote_p1.lua': return cfg
        if path == 'SCRIPT/Systems/engine_api.lua':
            return v.execute(read('Cockpit/Scripts/Systems/engine_api.lua'))
        raise AssertionError('unexpected load path '+path)
    v.globals().dofile=dofile
    v.execute(source)
    check('SCRIPT/Systems/engine_api.lua' in loaded, 'engine API load path')
    if 'ocelote_p1' in source:
        check('SCRIPT/Systems/CMFD/ocelote_p1.lua' in loaded, 'new config load path')
        check(v.globals().params['EICAS_TQ_OPT_VALID'].value == 0, 'initial hidden state')
    return v, cfg

for ref in valid+invalid:
    if isinstance(ref, dict): continue
    v,c=eicas_vm(read(EICAS),ref)
    for wow in [0,1]:
        v.globals().wow=wow
        v.globals().update_eicas()
        p=v.globals().params
        angle,visible=c.torque_marker(ref)
        check(p['EICAS_TQ_OPT_VALID'].value == visible, 'full EICAS visibility')
        check(math.isclose(p['EICAS_TQ_OPT_ROT'].value,angle,abs_tol=1e-12), 'full EICAS rotation')
# Test transition from valid reference to invalid, with no stale visible marker.
v,c=eicas_vm(read(EICAS),87)
v.globals().update_eicas(); c.tq_reference_percent=False; v.globals().update_eicas()
check(v.globals().params['EICAS_TQ_OPT_VALID'].value == 0, 'no stale marker')
# Isolate actual marker construction; DCS rendering/controller evaluation is simulated.
s=read(INDICATOR)
start=s.rfind('mesh_poly                   = CreateElement',0,s.index('"EICAS_TQ_OPT_ROT"'))
end=s.index('mesh_poly = nil',start)+len('mesh_poly = nil')
iv=lua(); iv.execute('''
    page_root={name="root"}; CMFDNu=1; CMFD_MATERIAL_CYAN="cyan"
    function CreateElement(t) return {class=t} end
    function AddElementObject(t) marker=t end
'''); iv.execute(s[start:end])
m=plain(iv.globals().marker)
check(m['element_params'] == {1:'EICAS_TQ_OPT_ROT',2:'CMFD1_BRIGHT',3:'EICAS_TQ_OPT_VALID'}, 'controller binding')
check(m['controllers'][1] == {1:'rotate_using_parameter',2:0,3:1.0}, 'needle gain parity')
check(m['controllers'][2] == {1:'parameter_in_range',2:2,3:0.5,4:1.5}, 'validity gate')
check(m['controllers'][3] == {1:'opacity_using_parameter',2:1}, 'brightness binding')
for percent in valid:
    angle,visible=config.torque_marker(percent)
    for brightness in [0,0.4,1]:
        simulated_opacity=(1 if 0.5 <= visible <= 1.5 else 0)*brightness
        check(simulated_opacity == brightness, 'endpoint/brightness visibility mock')
check(not (0.5 <= 0 <= 1.5), 'invalid visibility gate')
print('PASS: marker valid/invalid inputs, endpoints, ground/air, update integration and controller mocks')

# Execute entry.lua and its five local dofile targets with registration mocks.
ev=db("")
ev.globals().current_mod_path=str(root)
ev.execute('''
    function declare_plugin(id,t) plugin_id=id; plugin=t end
    function declare_weapon(t) return t end
    mount_vfs_sound_path=noop
    function make_view_settings(id,v,s) view_id=id end
    function make_flyable(id,path,fm,comm) flyable_id=id; flyable_fm=fm end
    function plugin_done() plugin_finished=true end
''')
entry_paths=[]
def entry_dofile(path):
    target=Path(path).resolve()
    check(target.is_relative_to(root) and target.is_file(), 'entry load path exists')
    entry_paths.append(target.relative_to(root).as_posix())
    return ev.execute(target.read_text())
ev.globals().dofile=entry_dofile
ev.execute(read('entry.lua'))
check(entry_paths == ['FM/config.lua','loadout.lua','weapons.lua','A-29B.lua','Views.lua'], 'entry load order')
check(ev.globals().plugin_id == ev.globals().flyable_id == 'A-29B', 'aircraft identity')
check(ev.globals().plugin.version == '0.8.0-OCELOTE-P1', 'local version')
check(ev.globals().plugin.InputProfiles['A-29B'] == str(root)+'/Input/A-29B', 'controls profile path')
check(ev.globals().flyable_fm[2] == 'avSimplest', 'EFM binary reference unchanged')
check(ev.globals().plugin_finished is True, 'entry finished in mock')
check('"Systems/CMFD/eicas.lua"' in read('Cockpit/Scripts/Systems/cmfds.lua'), 'EICAS system load route')
check('cmfd_page_path .. "CMFD_EICAS.lua"' in read('Cockpit/Scripts/CMFD/CMFD_init_COMMON.lua'), 'EICAS page load route')
print('PASS: entry load order, local paths, EICAS routes, aircraft/control identities (API mocks)')

if args.source_zip:
    with zipfile.ZipFile(args.source_zip) as z:
        baseline={n[len('A-29/'):]:z.read(n) for n in z.namelist() if n.startswith('A-29/') and not n.endswith('/')}
    actual={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()}
    changed={n for n,b in baseline.items() if actual.get(n) != b}
    check(changed == MODIFIED, 'exactly six modified files')
    check(set(actual)-set(baseline) == {CONFIG}, 'exactly one new production file')
    old_loads=plain(db(baseline['loadout.lua'].decode()).globals().loads)
    check({k:v for k,v in loads.items() if k not in [under,ventral]} == old_loads, 'all legacy/non-tank loads unchanged')
    old_air=plain(db(baseline['A-29B.lua'].decode()).globals().aircraft)
    for p in air['Pylons'].values():
        p[7]={i+1:item for i,item in enumerate(item for item in p[7].values() if item['CLSID'] not in [under,ventral])}
    check(air == old_air, 'all aircraft data unchanged except new tank options')
    old_fm=lua(); old_fm.execute(baseline['FM/config.lua'].decode())
    old_gear=plain(old_fm.globals().suspension)
    gear[3]['wheel_radius']=old_gear[3]['wheel_radius']
    gear[3]['amortizer_direct_damper_force_factor']=old_gear[3]['amortizer_direct_damper_force_factor']
    check(gear == old_gear, 'only two right-main suspension values changed')
    check(plain(fm.globals().A29B) == plain(old_fm.globals().A29B), 'CG/inertia unchanged')
    old_ec,_=eicas_vm(baseline[EICAS].decode()); new_ec,_=eicas_vm(read(EICAS),87)
    for wow in [0,1]:
        for rpm in [0,0.646,0.84,0.9,1,1.1]:
            for e in [old_ec,new_ec]:
                e.globals().wow=wow; e.globals().rpm=rpm; e.globals().update_eicas()
            before={k:v.value for k,v in old_ec.globals().params.items() if k != 'EICAS_TQ_OPT_ROT'}
            after={k:v.value for k,v in new_ec.globals().params.items() if k not in ['EICAS_TQ_OPT_ROT','EICAS_TQ_OPT_VALID']}
            check(before == after, 'all unrelated EICAS outputs unchanged')
    # Original return calculation: 10 NM * 1 kg/NM + zero BINGO = 10 kg.
    r=new_ec.globals().params['EICAS_FUEL_JOKER_ROT'].value
    check(math.isclose(r,(115.5-55/300*10)*math.pi/180), 'original return calculation unchanged')
    print('PASS: source ZIP audit, unrelated payload/aircraft/FM data and 12 EICAS regression scenarios')
else:
    print('NOT RUN: source-archive regression/audit (supply --source-zip to enable)')
print(f'PASS: {checks} assertions; DCS/EFM execution NOT performed')
