# OCELOTE P1 — registro de validación

Fecha: 26 de octubre de 2026. Plataforma de prueba: Linux, Python 3.12.14,
Lupa 2.6 con **Lua 5.1** (`lupa.lua51`, confirmado por `_VERSION`).
Entrada de código: `A-29.zip` suministrado por el usuario, 744401 bytes,
215 entradas. Se trabajó directamente sobre su extracción, sin crear un árbol
de originales o material de restauración. El ZIP grande anterior no se pudo
transferir por el límite de 32 MiB. Esta entrega se basa en el ZIP reducido.
El PDF aportado tiene 518 páginas; se comprobaron las páginas 14, 15 y 40.

## Pruebas ejecutadas y resultados

**Aprobadas: 289 aserciones**, con comparación de solo lectura contra el ZIP
aportado. Se repitió la ejecución final con los mismos resultados. También se
probó el modo sin archivo de entrada: 266 aserciones aprobadas y comparación
histórica informada explícitamente como no ejecutada.

```text
PASS: 7 production Lua files compile under Lua 5.1
PASS: tank balances, permitted stations, legacy ID and symmetric suspension (mock registration)
PASS: marker valid/invalid inputs, endpoints, ground/air, update integration and controller mocks
PASS: entry load order, local paths, EICAS routes, aircraft/control identities (API mocks)
PASS: source ZIP audit, unrelated payload/aircraft/FM data and 12 EICAS regression scenarios
PASS: 289 assertions; DCS/EFM execution NOT performed
```

| Comprobación | Alcance real |
|---|---|
| Sintaxis | `loadstring` de Lua 5.1 compila los seis Lua modificados y el nuevo; sin bytecode generado |
| Tanques | Ejecución real de `loadout.lua` con `declare_loadout` simulado; verifica 54,6 kg secos, 297,6/278,6 kg llenos, 243/224 kg de diferencia y 6 kg no utilizables |
| Estaciones | Ejecución de `A-29B.lua` con registro simulado; subalar solo 2/4, ventral solo 3, legado aún 2/3/4 |
| Regresión de cargas | Todas las declaraciones originales, incluso el tanque legado y las cargas ajenas, iguales a la entrada; avión completo igual salvo opciones nuevas de tanque |
| Suspensión | Ejecución de `FM/config.lua`: radios 0,563, amortiguación directa 52500; solo dos valores derechos cambian. CG e inercias iguales |
| Configuración del marcador | Por defecto `false`. Valores válidos 20, 20,01, 50, 70, 87, 100, 119,99, 120; se verifica la fórmula angular |
| Entradas inválidas | Ausencia, booleanos, cadena, cadena vacía, tabla, NaN, infinitos y valores fuera de escala; ocultos en la función de configuración |
| Integración EICAS | Ejecución de `eicas.lua` completo y `engine_api.lua` real, con sensores, parámetros, electricidad y avisos simulados; casos de tierra/vuelo y transición válido→inválido |
| Presentación | Se ejecuta el bloque real de construcción del marcador con elementos simulados; se verifican índices de parámetros, ganancia 1,0, puerta de validez, extremos y brillo 0/0,4/1. La evaluación de visibilidad es simulada, no renderizada por DCS |
| Regresión EICAS | 12 escenarios: RPM simulada 0 / 0,646 / 0,84 / 0,9 / 1 / 1,1, en tierra y vuelo. Todos los demás parámetros publicados coinciden con la entrada, incluidos TQ, Np, T5 y combustible |
| Retorno | Distancia simulada de 10 NM añade 10 kg al BINGO, según el algoritmo original |
| Rutas y registro | Ejecución de `entry.lua` y sus cinco `dofile` locales: FM, cargas, armas, avión, vistas. APIs de registro simuladas. Rutas existentes, identidad A-29B, ruta de perfil de controles y referencia avSimplest conservadas. Se comprueban también las referencias a la página y sistema EICAS |
| Alcance del cambio | Comparación en memoria con el ZIP: exactamente seis archivos modificados y un Lua nuevo; revisión del diff sin guardarlo como material de entrega |

No hubo aserciones fallidas. Las pruebas comparan declaraciones y ejecución Lua;
las constantes DCS se representan mediante nombres simbólicos. El registro de
cargas no demuestra que DCS reconozca los nuevos tanques ni que el EFM consuma
la diferencia de masas. Tampoco se ejecutó el entorno completo de la cabina ni
se comprobó la aceptación de versión en el gestor real de DCS.

La prueba se ejecutó sobre el árbol de trabajo completo del ZIP reducido. El
parche distribuido contiene solo los archivos modificados/nuevos: el ensayo
reproducible necesita el mod completo ya parcheado, según INSTALACION.md.

## Primera sesión pendiente en DCS — orden recomendado

1. **Carga y apoyo estático.** Registrar versión de DCS, estado inicial frío o
   caliente, masa/configuración y errores de `dcs.log`. Comprobar apoyo de las
   tres ruedas, altura, inclinación lateral, hundimiento, vibraciones y colisiones.
2. **Simetría experimental.** Comparar izquierda/derecha con cargas equilibradas
   y la misma superficie. Rodaje lento, giros en ambos sentidos y frenado
   progresivo; registrar deriva, rebotes y diferencias. No se ha demostrado aún
   que 0,563 y 52500 sean valores físicos correctos.
3. **Tanques y misiones.** Abrir una misión existente con el CLSID legado y
   comprobar que carga. Después retirar/reseleccionar los nuevos tanques. Revisar
   nombres, modelos, conectores y estaciones: subalares solo 2/4, ventral solo 3.
4. **Masa efectiva.** Conservar combustible interno, tripulación y demás cargas.
   El incremento declarado por tanque lleno es 297,6 kg subalar y 278,6 kg ventral,
   sin pilón. Tres nuevos tanques suman 873,8 kg llenos o 163,8 kg secos, con
   710 kg utilizables externos y 18 kg externos no utilizables dentro de la masa
   seca. Descontar/separar cualquier masa de pilones contabilizada por DCS.
5. **Combustible reconocido y transferencia.** Registrar por separado masa,
   combustible de DCS/EFM e indicaciones. Con 495 kg internos por gravedad,
   el objetivo declarado es 1205 kg utilizables en total; con 480 internos por
   presión, 1190 kg. Medir qué reconoce el EFM, si transfiere desde ambos
   subalares y ventral, qué ocurre al agotarlos y la masa residual. Verificar
   además soltado/rearme cuando corresponda. No deducirlo solo del EICAS limitado
   a 495 kg. Si el EFM ignora los CLSID nuevos o contabiliza de otro modo los
   6 kg, registrar el fallo; las pruebas de tablas no lo resuelven.
6. **Marcador en ambos CMFD.** Con `false`, oculto en tierra/vuelo; con una
   referencia válida, alineación con la escala y brillo. Probar 20 y 120, un
   valor inválido y el ejemplo condicionado de 87. Confirmar que no se altera
   la aguja TQ ni la respuesta del motor. Reiniciar misión entre configuraciones.
7. **Comparación de prestaciones posterior.** Solo después de lo anterior,
   igualar masa, atmósfera, configuración, ECS/OBOGS, separador y régimen del
   manual; registrar medidas antes de proponer cambios de masa base o del EFM.

**DCS: no ejecutado. EFM: no ejecutado.** No se declara probado el vuelo,
la transferencia, la masa física ni la suspensión dentro del simulador.
