declare_loadout({
	category		 = CAT_FUEL_TANKS,
	CLSID			 = "{A-29B TANK}",
	attribute		 =  {wsType_Air,wsType_Free_Fall,wsType_FuelTank,WSTYPE_PLACEHOLDER},


	LandRWCategories = 
    {
        [1] = { Name = "AircraftCarrier",},
        [2] = { Name = "AircraftCarrier With Catapult",}, 
        [3] = { Name = "AircraftCarrier With Tramplin",}, 
    }, -- end of LandRWCategories
    TakeOffRWCategories = 
    {
        [1] = {Name = "AircraftCarrier",},
        [2] = {Name = "AircraftCarrier With Catapult",}, 
        [3] = { Name = "AircraftCarrier With Tramplin",}, 
    }, -- end of TakeOffRWCategories

	Picture			 = "ptb2.png",
	displayName		 = _("A-29B TANK"),
	Weight_Empty	 = 40.8,
	Weight			 = 40.8 +  230.3,
	Cx_pil			 = 0.002,
	shape_table_data = 
	{
		{
			name 	= "A-29B TANK",
			file	= "A-29B TANK";
			life	= 1;
			fire	= { 0, 1};
			username	= "A-29B TANK";
			index	= WSTYPE_PLACEHOLDER;
		},
	},
	Elements	= 
	{
		{
			ShapeName	= "A-29B TANK",
		}, 
	}, 
})

-- OCELOTE P1: manual Fig. 1-1/1-2, PDF 14/15.
-- Weight_Empty includes 48.6 kg hardware + 6 kg unusable fuel.
-- Weight - Weight_Empty is the intended usable fuel; verify EFM in DCS.
-- The legacy declaration above registers the shared model and stays compatible.
local function declare_ocelote_tank(clsid, label, usable_fuel)
    declare_loadout({
        category = CAT_FUEL_TANKS,
        CLSID = clsid,
        attribute = {wsType_Air, wsType_Free_Fall, wsType_FuelTank, WSTYPE_PLACEHOLDER},
        LandRWCategories = {
            {Name = "AircraftCarrier"},
            {Name = "AircraftCarrier With Catapult"},
            {Name = "AircraftCarrier With Tramplin"},
        },
        TakeOffRWCategories = {
            {Name = "AircraftCarrier"},
            {Name = "AircraftCarrier With Catapult"},
            {Name = "AircraftCarrier With Tramplin"},
        },
        Picture = "ptb2.png",
        displayName = _(label),
        Weight_Empty = 48.6 + 6,
        Weight = 48.6 + 6 + usable_fuel,
        Cx_pil = 0.002, -- retained mod value; NOT derived from manual drag index
        Elements = {{ShapeName = "A-29B TANK"}},
    })
end

declare_ocelote_tank("{OCELOTE_P1_TANK_UNDERWING}",
    "OCELOTE P1 - Underwing tank (243 kg usable)", 243)
declare_ocelote_tank("{OCELOTE_P1_TANK_VENTRAL}",
    "OCELOTE P1 - Ventral tank (224 kg usable)", 224)

declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{SMOKE-WHITE-A29B}",
		Picture	= "fumo.png",
		PictureBlendColor= '0xffffffff',		
		displayName		= _("White Smoke"),
		
		attribute	=	{4,	15,	50,	WSTYPE_PLACEHOLDER},			
		Smoke  = {
			alpha = 180,
			r  = 255,
			g  = 255,
			b  = 255,
			dx = -1.455,
			dy = -0.062
		},
		
		shape_table_data = 
		{
			{
				name 	= "A29B_SMOKE-POD",
				file	= "A29B_SMOKE-POD";
				life	= 1;
				fire	= { 0, 1};
				username	= "SMOKE_WHITE_A29B";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Weight			= 1,
		Count 			= 1,
		Cx_pil			= 0.0,--0.001313754,
		Elements		={{
							ShapeName	=	"A29B_SMOKE-POD", 
							Position	=	{0,- 0.059317,0}, 
							DrawArgs	=	{[3] = {3,0.1}}
						}}
	}
)

declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{SMOKE-RED-A29B}",
		Picture	= "fumo.png",
		PictureBlendColor= '0xc81e1eff',	
		displayName		= _("Red Smoke"),
		
		attribute	=	{4,	15,	50,	WSTYPE_PLACEHOLDER},			
		Smoke  = {
			alpha = 180,
			r  = 204,
			g  = 0,
			b  = 51,
			dx = -1.455,
			dy = -0.062
		},
		
		shape_table_data = 
		{
			{
				name 	= "A29B_SMOKE-POD",
				file	= "A29B_SMOKE-POD";
				life	= 1;
				fire	= { 0, 1};
				username	= "SMOKE_RED_A29B";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Weight			= 1,
		Count 			= 1,
		Cx_pil			= 0.0,--0.001313754,
		Elements		={{
							ShapeName	=	"A29B_SMOKE-POD", 
							Position	=	{0,- 0.059317,0}, 
							DrawArgs	=	{[3] = {3,0.1}}
						}}
	}
)

declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{SMOKE-GREEN-A29B}",
		Picture	= "fumo.png",
		PictureBlendColor= '0x228b22ff',
		displayName		= _("Green Smoke"),
		
		attribute	=	{4,	15,	50,	WSTYPE_PLACEHOLDER},			
		Smoke  = {
			alpha = 180,
			r  = 34,
			g  = 139,
			b  = 34,
			dx = -1.455,
			dy = -0.062
		},
		
		shape_table_data = 
		{
			{
				name 	= "A29B_SMOKE-POD",
				file	= "A29B_SMOKE-POD";
				life	= 1;
				fire	= { 0, 1};
				username	= "SMOKE_GREEN_A29B";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Weight			= 1,
		Count 			= 1,
		Cx_pil			= 0.0,--0.001313754,
		Elements		={{
							ShapeName	=	"A29B_SMOKE-POD", 
							Position	=	{0,- 0.059317,0}, 
							DrawArgs	=	{[3] = {3,0.1}}
						}}
	}
)
-----------------------------------------SMOKE DIANA 61------------------------------------------------------
declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{SMOKE-BLACK-A29B}",
		Picture	= "fumo.png",
		PictureBlendColor= '0x000000ff',	
		displayName		= _("Black Smoke"),
		
		attribute	=	{4,	15,	50,	WSTYPE_PLACEHOLDER},			
		Smoke  = {
			alpha = 100,
			r  = 0,
			g  = 0,
			b  = 20,
			dx = -1.455,
			dy = -0.062
		},
		
		shape_table_data = 
		{
			{
				name 	= "A29B_SMOKE-POD",
				file	= "A29B_SMOKE-POD";
				life	= 1;
				fire	= { 0, 1};
				username	= "SMOKE_BLACK_A29B";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Weight			= 1,
		Count 			= 1,
		Cx_pil			= 0.0,--0.001313754,
		Elements		={{
							ShapeName	=	"A29B_SMOKE-POD", 
							Position	=	{0,- 0.059317,0}, 
							DrawArgs	=	{[3] = {3,0.1}}
						}}
	}
)

declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{SMOKE-ORANGE-A29B}",	--"{SMOKE-ORANGE-MB339}",
		Picture	= "fumo.png",
		PictureBlendColor= '0xfc9600ff',		
		displayName		= _("Orange Smoke"),
		
		attribute		=	{4,	15,	50,	WSTYPE_PLACEHOLDER},			
		Smoke  = {
			alpha = 180,
			r  = 255,
			g  = 108,
			b  = 0,
			dx = -1.455,
			dy = -0.062
		},
		
		shape_table_data = 
		{
			{
				name 	= "smoke-pod",
				file	= "smoke_pod";
				life	= 1;
				fire	= { 0, 1};
				username	= "SMOKE_ORANGE_A29B";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Weight			= 1,
		Count 			= 1,
		Cx_pil			= 0.0,--0.001313754,
		Elements		={{
							ShapeName	=	"smoke_pod", 
							Position	=	{0,- 0.059317,0}, 
							DrawArgs	=	{[3] = {3,0.1}}
						}}
	}
)

declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{SMOKE-YELLOW-A29B}",
		Picture	= "fumo.png",
		PictureBlendColor= '0xffff00ff',		
		displayName		= _("Yellow Smoke"),
		
		attribute		=	{4,	15,	50,	WSTYPE_PLACEHOLDER},			
		Smoke  = {
			alpha = 180,
			r  = 255,
			g  = 218,
			b  = 0,
			dx = -1.455,
			dy = -0.062
		},
		
		shape_table_data = 
		{
			{
				name 	= "smoke-pod",
				file	= "smoke_pod";
				life	= 1;
				fire	= { 0, 1};
				username	= "SMOKE_YELLOW_A29B";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Weight			= 1,
		Count 			= 1,
		Cx_pil			= 0.0,--0.001313754,
		Elements		={{
							ShapeName	=	"smoke_pod", 
							Position	=	{0,- 0.059317,0}, 
							DrawArgs	=	{[3] = {3,0.1}}
						}}
	}
)

declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{FLIR-STAR-SAFIRE}",
		attribute		= {4,	15,	44,	WSTYPE_PLACEHOLDER},			
		Weight			= 47.2 + 11.1 + 1.1 + 2.1, 
		Count 			= 1,
		Cx_pil			= 0.0005949,
		Picture			= "starsafire.png",
		PictureBlendColor= '0xffffffff',		
		displayName		= _("FLIR Star Safire Turret"),
		shape_table_data = 
		{
			{
				file	= "FLIR-STAR-SAFIRE";
				life	= 1;
				fire	= { 0, 1};
				username	= "FLIR-STAR-SAFIRE";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		
		Elements		={
			{
				ShapeName	=	"FLIR-STAR-SAFIRE", 
			}
		},
		Sensors	 = 
		{
			OPTIC  = {"FLIR Star Safire"},
		},
	}
)
