-- OCELOTE P1: per-test reference, NOT an engine model or automatic power limit.
local config = {
    -- false: hidden. Set a numeric percentage in [20, 120], then restart mission.
    -- Example ONLY: 87 at 2000 ft pressure altitude, 21 C / ISA+10,
    -- ECS OFF, OBOGS OFF, inertial separator OPEN (manual PDF 40).
    tq_reference_percent = false,
}

function config.torque_marker(percent)
    -- Reject invalid / non-finite / off-scale values; do not invent a limit.
    if type(percent) ~= "number" or percent ~= percent
        or percent < 20 or percent > 120 then
        return 0, 0 -- rotation (rad), visible
    end
    -- Exact scale of the original EICAS torque needle (including endpoints).
    return -(percent - 70) * math.pi / 60, 1
end

return config
