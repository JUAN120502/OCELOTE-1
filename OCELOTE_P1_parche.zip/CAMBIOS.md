# OCELOTE P1 — cambios y fundamento

## Datos publicados comprobados

Referencia: PDF suministrado TO 1A-29B(CO)-1-2, suplemento de prestaciones,
revisión 9, 20 de octubre de 2021, 518 páginas. Las hojas conservan revisiones
individuales: PDF 14 dice revisión 8, PDF 15 revisión 6 y PDF 40 revisión 2.

Figura 1-1, impresa 1-8 / PDF 14, y figura 1-2, impresa 1-9 / PDF 15:

| Magnitud, kg por tanque | Subalar | Ventral |
|---|---:|---:|
| Hardware vacío | 48,6 | 48,6 |
| Combustible total | 249 | 230 |
| Utilizable | 243 | 224 |
| No utilizable | 6 | 6 |
| Lleno sin pilón | 297,6 | 278,6 |
| Masa seca elegida en la declaración P1 | 54,6 | 54,6 |

PDF 14: combustible interno utilizable por gravedad 495 kg (total 509), por
presión 480 kg (total 495). La tabla de referencia de peso indica equipado
vacío 3366 kg, combustible interno no utilizable 13 kg, aceite hidráulico
2,7 kg, aceite de motor 20 kg, básico vacío 3401,7 kg y dos tripulantes,
180 kg, para un básico operacional de 3581,7 kg. La nota exige consultar el
formulario de pesaje para el peso real del avión; las capacidades presuponen
alas niveladas y densidad 0,785 kg/l. No se iguala automáticamente la referencia
de fluidos de esa tabla a cualquier escenario de llenado.

PDF 40 / impresa 2-2: ejemplo de 87 % condicionado a 2000 ft, 21 °C, ISA +10,
ECS OFF, OBOGS OFF y separador abierto. No es una referencia universal.

## Decisiones de implementación

- `loadout.lua`: dos definiciones nuevas con CLSID
  `{OCELOTE_P1_TANK_UNDERWING}` y `{OCELOTE_P1_TANK_VENTRAL}`. Usan la misma
  categoría `CAT_FUEL_TANKS` y los campos `Weight_Empty` y `Weight` del original.
  Se interpreta el primero como masa seca y el segundo como masa llena:
  `Weight_Empty = 48.6 + 6`; `Weight = Weight_Empty + usable_fuel`.
  La diferencia es 243 o 224 kg, y los 6 kg quedan en masa seca, no en esa
  diferencia consumible. Es una representación en la interfaz de declaración
  del mod; la prueba simulada comprueba las tablas, no su interpretación en DCS.
  No se recibió documentación o fuente del EFM que garantice que este derive
  combustible de esos campos o acepte los nuevos CLSID: pendiente en DCS.
  Se reutiliza el modelo registrado por el tanque antiguo. `Cx_pil = 0.002`
  permanece igual; no se convierte el DI del manual a coeficiente aerodinámico.
- `A-29B.lua`: añade subalares únicamente a 2 y 4, ventral únicamente a 3.
  Conserva la definición y selecciones antiguas para compatibilidad. Las demás
  opciones, coordenadas y propiedades de los pilones no cambian.
- `M_fuel_max = 495` y `M_empty = 3356` permanecen. No se demuestra que la masa
  vacía declarada incluya o excluya los mismos elementos que el manual. La
  existencia de dos puestos y la opción `SoloFlight` con `weightWhenOn = -80`
  no resuelven cómo DCS y el EFM contabilizan tripulación, fluidos y combustible
  no utilizable. No se aplica +10 kg ni se declara corregido el peso operacional.
- `eicas.lua`, `CMFD_EICAS.lua` y el nuevo `ocelote_p1.lua`: sustituyen el
  marcador universal en tierra por una referencia explícita por ensayo, oculta
  de forma predeterminada. Rango válido [20,120], escala angular exacta
  `-(porcentaje - 70) * pi / 60`, ganancia del controlador 1,0 en lugar de 1,1,
  visibilidad mediante `EICAS_TQ_OPT_VALID`, brillo original conservado.
  No cambian la conversión RPM–TQ, Np, T5, alarmas ni la aguja de torque.
- Retorno: se conserva `cruise_flow = 1.0 / 1852`, que suma 1 kg por NM de
  distancia horizontal al homepoint al BINGO configurado. No es el consumo
  físico del motor ni una implementación de tablas de crucero; no predice el
  viento ni condiciones de la ruta de regreso. No se añade opción flujo/TAS.
- `entry.lua`: versión local `0.8.0-OCELOTE-P1`, identificadores y perfiles
  originales conservados. El campo original aún decía `0.6.0b`, aunque el README
  del ZIP documenta 0.8.0. OCELOTE P1 es una modificación local, no atribuida al
  autor original; sus créditos siguen identificando el mod base.

## Ajuste experimental

`FM/config.lua`: se toma el lado principal izquierdo original como referencia;
ambos radios principales quedan en 0,563 y los factores de amortiguación directa
en 52500. Solo cambian los dos valores del lado derecho. Las constantes no
proceden del suplemento y no constituyen una corrección física demostrada.
La tabla local `mainGear` no usada por `suspension` permanece igual. No se
reducen radios a la mitad. CG, inercias, fricción y frenado no cambian.

## Límites y pendientes

No se editó ni ejecutó `avSimplest.dll`; el ZIP reducido no lo incluye y no
contiene sus fuentes C++. No se recalibró el EFM ni se modificó `SFM_Data`.
Las nuevas masas declaradas no prueban cambios efectivos del vuelo del jugador.

El EICAS original limita su indicación interna a 495 kg y reparte el combustible
izquierdo/derecho con un modelo simplificado. Su totalizador utiliza un valor
inicial y consumo integrado. No se alteró esa lógica: no debe usarse como única
prueba de cantidad externa reconocida o transferencia. También permanece el
máximo original del totalizador de 1465 kg. Registra por separado el combustible
real reconocido por DCS/EFM, las indicaciones y la transferencia observable.
