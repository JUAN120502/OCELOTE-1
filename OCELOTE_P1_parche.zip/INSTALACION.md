# OCELOTE P1 — instalación y uso

Parche local experimental sobre los archivos suministrados de A-29B Community
0.8.0. No es una publicación del autor original. La versión visible del plugin
pasa a `0.8.0-OCELOTE-P1`; se conservan sus créditos y los identificadores A-29B.

## Instalar

1. Cierra DCS. Debes tener instalado el mod completo A-29B Community 0.8.0.
   Este parche no incluye DLL, modelos, texturas, sonidos ni todos los scripts.
2. Abre la carpeta instalada del mod dentro de
   `%USERPROFILE%\Saved Games\DCS\Mods\aircraft\` o de tu perfil DCS correspondiente.
   Identifica la carpeta que contiene `entry.lua`, `A-29B.lua`, `loadout.lua`,
   `FM` y `Cockpit`. No deduzcas su nombre a partir de la carpeta `A-29` del ZIP.
3. Copia **el contenido** de `A-29/` del parche dentro de esa carpeta, conservando
   sus rutas relativas y reemplazando los seis archivos existentes. El séptimo,
   `Cockpit/Scripts/Systems/CMFD/ocelote_p1.lua`, es nuevo. No anides otra carpeta
   `A-29` dentro del mod y no sustituyas la carpeta completa: combina su contenido.
4. No copies `VALIDACION/` ni los Markdown en las carpetas de scripts.
   No cambies `Saved Games\…\Config\Input`, los perfiles personales ni el DLL.
5. Inicia DCS y verifica la versión local, la carga del avión y ambas páginas EICAS.
   Si hay errores, registra el mensaje y la ruta en `Saved Games\…\Logs\dcs.log`.

No se suministran originales, copias de restauración ni archivos de respaldo.

## Seleccionar los tanques P1

En el editor de misiones o rearme, retira la carga antigua de las estaciones
2, 3 y 4 y vuelve a seleccionarla con estos nombres:

- Estaciones 2 y 4: `OCELOTE P1 - Underwing tank (243 kg usable)`.
- Estación 3: `OCELOTE P1 - Ventral tank (224 kg usable)`.

Guarda la misión después de seleccionar las nuevas cargas. El identificador
`{A-29B TANK}` y su definición original permanecen disponibles para misiones
existentes; no hay migración automática. `A-29B TANK` sigue usando los valores
antiguos y no sirve para validar las masas P1. Los tanques nuevos reutilizan
el modelo existente; no necesitan un archivo de modelo nuevo.

## Configurar la referencia de torque de cada ensayo

Edita `Cockpit/Scripts/Systems/CMFD/ocelote_p1.lua` antes de iniciar la misión:

```lua
tq_reference_percent = false, -- oculto, valor predeterminado
```

Puedes sustituir `false` por un número de 20 a 120, ambos incluidos, con punto
decimal si corresponde. Reinicia la misión para recargarlo. Las cadenas como
`"87"`, booleanos, valores no finitos y números fuera de escala ocultan el
marcador. No se redondean a un límite ficticio. Conserva sintaxis Lua válida:
un error de sintaxis en el archivo impide cargarlo.

El valor `87` solo representa el ejemplo del manual: torque de despegue a máxima
potencia continua, 2000 ft de presión, 21 °C / ISA +10 °C, ECS OFF, OBOGS OFF y
separador inercial abierto. La configuración no comprueba esas condiciones ni
calcula un límite automático. El marcador se muestra con la misma referencia
en tierra y en vuelo; `false` lo oculta en ambos. No limita la potencia del motor.

## Combustible interno

El máximo sigue siendo 495 kg utilizables por gravedad. Para el ensayo de
llenado a presión, carga 480 kg internos (96,9697 % del máximo), sin imponerlo
a otras misiones. Si la interfaz redondea el porcentaje, registra el combustible
real resultante: 97 % representa 480,15 kg sobre un máximo de 495 kg.

## Validación de código opcional

En una máquina con Python y el mod completo parcheado:

```text
python -m pip install lupa==2.6
python VALIDACION/validar_p1.py "RUTA_A_LA_CARPETA_DEL_MOD"
```

El ensayo usa `lupa.lua51`, no el intérprete Lua predeterminado de Lupa. Lee
archivos y simula APIs; no inicia DCS, no carga el DLL y no crea copias. Sin el
ZIP de entrada, la comparación histórica se informa como no ejecutada. Véase
`VALIDACION/RESULTADOS.md` para lo que se ejecutó durante esta entrega.
